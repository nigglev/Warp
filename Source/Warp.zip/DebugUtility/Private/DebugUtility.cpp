﻿#include "DebugUtility.h"

#define LOCTEXT_NAMESPACE "FDebugUtilityModule"

void FDebugUtilityModule::StartupModule()
{
    
}

void FDebugUtilityModule::ShutdownModule()
{
    
}

#undef LOCTEXT_NAMESPACE
    
IMPLEMENT_MODULE(FDebugUtilityModule, DebugUtility)